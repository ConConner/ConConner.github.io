ConCon's Map Mapper
-------------------

IMPORTANT:
your .cmf files from the older map mapper versions are NOT supported anymore!
The new file type is .mf (map file) and can only be loaded by Beta 2.0!

If you have any questions write a forum post, a message on Discord
or write an E-Mail to contendohelp@gmail.com

WINDOWS ONLY (no other platforms planned yet)

For help and reporting bugs write me a message on Discord or write an E-Mail to contendohelp@gmail.com

Discord: Conner#4315