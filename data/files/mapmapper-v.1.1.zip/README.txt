ConCon's Map Mapper
-------------------

For a beginner tutorial go to https://forum.metroidconstruction.com/index.php/topic,5240.0.html

WINDOWS ONLY (no other platforms planned yet)

For help and reporting bugs write me a message on Discord or write an E-Mail to contendohelp@gmail.com

Discord: Conner#1212